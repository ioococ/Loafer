create definer = root@localhost view v_student_english as
select `testdb`.`student`.`id` AS `编号`, `testdb`.`student`.`name` AS `姓名`, `testdb`.`student`.`english` AS `英语成绩`
from `testdb`.`student`;

