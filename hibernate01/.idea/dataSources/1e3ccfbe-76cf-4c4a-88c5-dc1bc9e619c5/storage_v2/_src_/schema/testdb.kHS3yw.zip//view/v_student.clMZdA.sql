create definer = root@localhost view v_student as
select `testdb`.`student`.`id`      AS `id`,
       `testdb`.`student`.`name`    AS `name`,
       `testdb`.`student`.`age`     AS `age`,
       `testdb`.`student`.`sex`     AS `sex`,
       `testdb`.`student`.`address` AS `address`,
       `testdb`.`student`.`math`    AS `math`,
       `testdb`.`student`.`english` AS `english`
from `testdb`.`student`;

