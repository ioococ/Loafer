create definer = root@localhost view v_student_math as
select `testdb`.`student`.`id` AS `id`, `testdb`.`student`.`name` AS `name`, `testdb`.`student`.`math` AS `math`
from `testdb`.`student`;

