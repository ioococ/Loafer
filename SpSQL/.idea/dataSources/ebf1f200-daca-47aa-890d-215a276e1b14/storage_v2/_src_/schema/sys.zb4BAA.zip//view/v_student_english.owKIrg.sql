create view v_student_english as
select `sys`.`student`.`id` AS `编号`, `sys`.`student`.`name` AS `姓名`, `sys`.`student`.`english` AS `英语成绩`
from `sys`.`student`;

