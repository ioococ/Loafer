create view v_student as
select `sys`.`student`.`id`      AS `id`,
       `sys`.`student`.`name`    AS `name`,
       `sys`.`student`.`age`     AS `age`,
       `sys`.`student`.`sex`     AS `sex`,
       `sys`.`student`.`address` AS `address`,
       `sys`.`student`.`math`    AS `math`,
       `sys`.`student`.`english` AS `english`
from `sys`.`student`;

