create view v_student_math as
select `sys`.`student`.`id` AS `id`, `sys`.`student`.`name` AS `name`, `sys`.`student`.`math` AS `math`
from `sys`.`student`;

