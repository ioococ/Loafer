create view vv_student as
select `v_student_english`.`编号` AS `编号`, `v_student_english`.`姓名` AS `姓名`, `v_student_english`.`英语成绩` AS `英语成绩`
from `test`.`v_student_english`;

