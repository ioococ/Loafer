create view v_student_english as
select `test`.`student`.`id` AS `编号`, `test`.`student`.`name` AS `姓名`, `test`.`student`.`english` AS `英语成绩`
from `test`.`student`;

