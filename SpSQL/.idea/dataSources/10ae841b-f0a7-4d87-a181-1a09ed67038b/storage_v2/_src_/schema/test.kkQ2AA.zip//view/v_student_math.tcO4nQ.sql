create view v_student_math as
select `test`.`student`.`id` AS `id`, `test`.`student`.`name` AS `name`, `test`.`student`.`math` AS `math`
from `test`.`student`;

