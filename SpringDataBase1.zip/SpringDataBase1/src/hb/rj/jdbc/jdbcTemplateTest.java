package hb.rj.jdbc;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class jdbcTemplateTest {
    public void createTable(String TableName){
        String XmlFile ="beans.xml";
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext(XmlFile);
        JdbcTemplate jdbcTemplate = applicationContext.getBean("jdbcTemplate",JdbcTemplate.class);
        jdbcTemplate.execute("create table "+TableName+"(userId int primary key auto_increment,username varchar(50),password varchar(10)) character set utf8");
    }
    public void DropTable(String TableName){
        //1.定义配置文件
        String XmlFile = "beans.xml";
        //2.加载
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext(XmlFile);
        JdbcTemplate jdbcTemplate = applicationContext.getBean("jdbcTemplate",JdbcTemplate.class);
        jdbcTemplate.execute("Drop table " + TableName);
    }
    @Test
    public void test(){
//        DropTable("Springuser");
        createTable("Springuser");
    }
}
