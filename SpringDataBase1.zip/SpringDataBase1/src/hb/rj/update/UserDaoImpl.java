package hb.rj.update;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import javax.swing.*;
import java.util.List;

public class UserDaoImpl implements UserDao{
    private JdbcTemplate jdbcTemplate;

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public int addUser(Springuser user) {
        System.out.println(user.getUsername());
        System.out.println(user.getPassword());
        String sql = "insert into SpringUser(username,password) value (?,?)";
        Object [] obj = new Object[]{
                user.getUsername(),
                user.getPassword(),
        };
        //获取数据返回的结果
        int flag = this.jdbcTemplate.update(sql,obj);
        return flag;
    }

    @Override
    public int updateUser(Springuser user) {
        String sql = "update springuser set username =?,password=? where userId=?";
        Object [] params = new Object[]{
                user.getUsername(),
                user.getPassword(),
                user.getUserId(),
        };
        int flag = this.jdbcTemplate.update(sql,params);
        return flag;
    }

    @Override
    public int deleteUserById(int id) {
        String sql ="delete from Springuser where uid=?";
        int flag = this.jdbcTemplate.update(sql,id);
        return flag;
    }

    @Override
    public Springuser findUserById(int id) {
        String sql = "select * from Springuser where userId=?";
        RowMapper<Springuser> rowMapper = BeanPropertyRowMapper.newInstance(Springuser.class);
        return this.jdbcTemplate.queryForObject(sql,rowMapper,id);
    }

    @Override
    public List<Springuser> findAllUser() {
        String sql = "select * from Springuser";
        RowMapper<Springuser> rowMapper = BeanPropertyRowMapper.newInstance(Springuser.class);
        return this.jdbcTemplate.query(sql,rowMapper);
    }
}
