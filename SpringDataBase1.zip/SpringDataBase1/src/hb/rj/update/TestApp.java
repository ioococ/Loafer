package hb.rj.update;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.swing.*;
import java.util.List;

public class TestApp {
    public ApplicationContext init(){
        //1.定义xml文件
        String XmlFile = "beans.xml";
        //2.加载配置文件
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext(XmlFile);
        return applicationContext;
    }
    @Test
    public void addUser(){
        //新增用户
        ApplicationContext applicationContext = init();
        UserDao userDao = (UserDao) applicationContext.getBean("userDao");
        Springuser user = new Springuser();
        user.setUsername("张三");
        user.setPassword("123456");
        int flag = userDao.addUser(user);
        if (flag == 1){
            System.out.println("数据添加成功");
        }else {
            System.out.println("数据添加失败");
        }
    }


    @Test
    public void updateUser(){
        ApplicationContext applicationContext = init();
        UserDao userDao = (UserDao) applicationContext.getBean("userDao",UserDao.class);
        Springuser user = new Springuser();
        user.setUserId(1);
        user.setUsername("李四");
        user.setPassword("8888");
        int flag = userDao.addUser(user);
        if (flag == 1){
            System.out.println("数据更新成功");
        }else {
            System.out.println("数据更新失败");
        }
    }

    @Test
    public void deleteUser(){
        ApplicationContext applicationContext = init();
        UserDao userDao = (UserDao) applicationContext.getBean("userDao",UserDao.class);
        int flag = userDao.deleteUserById(2);
        if (flag == 1){
            System.out.println("数据删除成功");
        }else {
            System.out.println("数据删除失败");
        }
    }

    @Test
    public void test(){

    }

    @Test
    public void findUserById(){
        ApplicationContext applicationContext = init();
        UserDao userDao = (UserDao)applicationContext.getBean("userDao");
        Springuser user = userDao.findUserById(1);
        System.out.println(user);
    }

    @Test
    public void findAllUser(){
        ApplicationContext applicationContext = init();
        UserDao userDao = (UserDao)applicationContext.getBean("userDao");
        List<Springuser> user = userDao.findAllUser();
        for (Springuser u:user){
            System.out.println(u);
        }
    }
}
