package hb.rj.update;

import javax.swing.*;
import java.util.List;

public interface UserDao {
    //添加用户
    public int addUser(Springuser user);
    //修改用户
    public int updateUser(Springuser user);
    //删除用户
    public int deleteUserById(int id);
    //查询用户
    //1)id
    public Springuser findUserById(int id);
    //2)所有
    public List<Springuser> findAllUser();
}

