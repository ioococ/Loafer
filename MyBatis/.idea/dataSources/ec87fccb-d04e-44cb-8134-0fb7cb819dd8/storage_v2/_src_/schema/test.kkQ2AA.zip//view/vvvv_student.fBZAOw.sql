create definer = root@localhost view vvvv_student as
select `test`.`student`.`id`      AS `id`,
       `test`.`student`.`name`    AS `name`,
       `test`.`student`.`age`     AS `age`,
       `test`.`student`.`sex`     AS `sex`,
       `test`.`student`.`address` AS `address`,
       `test`.`student`.`math`    AS `math`,
       `test`.`student`.`english` AS `english`
from `test`.`student`;

